#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#ifdef _OPENMP
#include <omp.h>
#endif

static int read_vector(double *v, int n) {
    for (int i = 0; i < n; ++i) {
        if (scanf("%lf", &v[i]) != 1) return -1;
    }
    return 0;
}

int main(void) {
    int p;
    if (scanf("%d", &p) != 1) {
        fprintf(stderr, "Error: could not read p\n");
        return 1;
    }
    if (p < 2) {
        fprintf(stderr, "Error: p must be >= 2\n");
        return 1;
    }
    const int N = 1 << p;

    double *a = (double*) malloc(sizeof(double)*N);
    double *b = (double*) malloc(sizeof(double)*N);
    double *c = (double*) malloc(sizeof(double)*N);
    double *d = (double*) malloc(sizeof(double)*N);
    double *a2 = (double*) malloc(sizeof(double)*N);
    double *b2 = (double*) malloc(sizeof(double)*N);
    double *c2 = (double*) malloc(sizeof(double)*N);
    double *d2 = (double*) malloc(sizeof(double)*N);
    double *x  = (double*) malloc(sizeof(double)*N);

    if (!a||!b||!c||!d||!a2||!b2||!c2||!d2||!x) {
        fprintf(stderr, "Error: memory allocation failed\n");
        return 1;
    }

    if (read_vector(a, N) || read_vector(b, N) || read_vector(c, N) || read_vector(d, N)) {
        fprintf(stderr, "Error: could not read vectors a,b,c,d\n");
        return 1;
    }

    // Parallel Cyclic Reduction: O(log N) stages; per-stage work is O(N) and embarrassingly parallel
    for (int s = 0; s < p; ++s) {
        const int stride = 1 << s;

        #pragma omp parallel for schedule(static)
        for (int i = 0; i < N; ++i) {
            double alpha = 0.0, gamma = 0.0;
            if (i - stride >= 0)    alpha = a[i] / b[i - stride];
            if (i + stride <  N)    gamma = c[i] / b[i + stride];

            const double a_l = (i - stride >= 0) ? a[i - stride] : 0.0;
            const double c_l = (i - stride >= 0) ? c[i - stride] : 0.0;
            const double d_l = (i - stride >= 0) ? d[i - stride] : 0.0;

            const double a_r = (i + stride <  N) ? a[i + stride] : 0.0;
            const double c_r = (i + stride <  N) ? c[i + stride] : 0.0;
            const double d_r = (i + stride <  N) ? d[i + stride] : 0.0;

            a2[i] = - a_l * alpha;
            b2[i] =   b[i] - c_l * alpha - a_r * gamma;
            c2[i] = - c_r * gamma;
            d2[i] =   d[i] - d_l * alpha - d_r * gamma;
        }

        // swap (a,b,c,d) with (a2,b2,c2,d2)
        double *tmp;
        tmp=a; a=a2; a2=tmp;
        tmp=b; b=b2; b2=tmp;
        tmp=c; c=c2; c2=tmp;
        tmp=d; d=d2; d2=tmp;
    }

    // Now the system is (almost) diagonal: x[i] = d[i]/b[i]
    #pragma omp parallel for schedule(static)
    for (int i = 0; i < N; ++i) {
        x[i] = d[i] / b[i];
    }

    for (int i = 0; i < N; ++i) {
        printf("%.6f ", x[i]);
    }
    printf("\n");

    free(a); free(b); free(c); free(d);
    free(a2); free(b2); free(c2); free(d2);
    free(x);
    return 0;
}